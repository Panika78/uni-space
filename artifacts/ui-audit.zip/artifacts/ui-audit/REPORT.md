# Визуальный аудит Uni Space

Дата: 19 ноября 2026. Локальный исходный checkout: `/workspace/uni-space`; текущая версия репозитория на момент запуска. Исследование выполнялось в headless Chromium 156 через Playwright, приложение действительно отрисовывалось (проверялся непустой текст DOM), дождались загрузки web fonts. Исходники приложения не менялись.

## Запуск и данные

- Изучены `AGENTS.md`, `README.md`, `docs/DEMO_DATA.md`, маршрутизатор frontend и repository E2E fixtures.
- Использован отдельный PostgreSQL test container из `compose.test.yaml` (`uni_space_test`, loopback `127.0.0.1:55432`), применены Alembic migrations.
- Загружен вымышленный demo seed; дополнительно использованы фикстуры `frontend/e2e/role-fixtures.py`, `admin-fixtures.py`, `teacher-journal-fixtures.py`. Пароли вымышленные, секреты в артефакты не записаны.
- API: `127.0.0.1:8011`; Vite: `127.0.0.1:5174` (порт 8000/5173 уже был занят в окружении); CORS настроен только для локального Vite origin.
- Student: `demo-pz101`; teacher: отдельная фикстура journal E2E; admin: `admin-browser-operator`; staff: `role-e2e-all`, `role-e2e-reviewer`, `role-e2e-empty`. Пароли не публикуются.

## Обнаруженные маршруты и покрытие

| Маршрут | Роль(и) | Снимков |
|---|---|---:|
| `/about` | auth | 1 |
| `/academics` | student | 3 |
| `/academics/courses/1` | student | 2 |
| `/admin/users` | admin | 3 |
| `/admin/users/1` | admin | 2 |
| `/admin/users/new` | admin | 2 |
| `/applications/1` | student | 2 |
| `/login` | auth | 3 |
| `/news` | student | 2 |
| `/news/1` | student | 1 |
| `/not-real` | shared | 1 |
| `/profile` | student | 2 |
| `/schedule` | student | 6 |
| `/services` | student | 2 |
| `/services/academic_leave` | student | 1 |
| `/services/academic_transcript` | student | 1 |
| `/services/certificate` | student | 2 |
| `/services/study_certificate` | student | 1 |
| `/settings` | shared | 2 |
| `/staff` | staff, staff-empty, staff-reviewer | 5 |
| `/staff/applications` | staff, staff-empty, staff-reviewer | 6 |
| `/staff/journals` | staff, staff-empty, staff-reviewer | 4 |
| `/staff/news` | staff, staff-empty, staff-reviewer | 4 |
| `/staff/schedule` | staff, staff-empty, staff-reviewer | 4 |
| `/staff/students` | staff, staff-empty, staff-reviewer | 4 |
| `/staff/students/status` | staff, staff-empty, staff-reviewer | 4 |
| `/teacher/journals` | teacher | 3 |
| `/teacher/schedule` | teacher | 2 |

Обнаружено 28 различных URL и 77 наблюдений/ссылок, сведённых к 66 уникальным PNG после удаления побайтных дублей. Desktop охвачен для основных страниц, student schedule дополнительно снят на 1280×800, 768×1024 и 320×700. Mobile 390×844 снят для основных student и каждой страницы teacher/admin/staff; login/about/404/settings тоже зафиксированы. Проверка `document.documentElement.scrollWidth <= innerWidth` не выявила горизонтального переполнения в сохранённых состояниях.

Сняты дополнительные состояния: открытая мобильная боковая навигация и drawer уведомлений (2 скриншота). В браузере выполнены вход, просмотр страниц, ошибочный вход, переходы по ссылкам новости и каталога услуг, а также одно нажатие на первый control в расписании/успеваемости. В фикстурах использовались разные разрешения и роли. Полный перебор всех комбинаций фильтров, табов и редакторов не завершён; отдельные модальные и expanded состояния не сохранены.

## Проблемы и наблюдения

1. **Успеваемость отвечает 500 на локальном объединённом наборе данных.** Маршруты `/academics` и `/academics/courses/1`, 1440×900 и 390×844. Шаги: войти студентом `demo-pz101`, открыть «Успеваемость» после добавления teacher journal fixture. API `GET /api/v1/academics` вернул 500; лог сервера: `MultipleResultsFound`. Ожидалось содержимое успеваемости; фактически UI показал recovery/error состояние. Фиксация: `student/academics/desktop-academics.png`, `student/academics/mobile-academics.png`, `student/academics_courses_id/desktop-academics_courses_id.png`. Причина может быть конфликтом фикстурных семестров; это дефект тестового сочетания, не подтверждён как дефект production данных.
2. **Не найденный detail id.** `/applications/1` и `/admin/users/1` открыты прямым URL без выбора объекта; application вернула 404, а не существующую деталь. Это сценарий несуществующего ID; валидная заявка не создавалась, чтобы не делать неоправданную предметную операцию.
3. **Teacher journal fixture отобразился без предварительно выбранного журнала.** `/teacher/journals`, desktop/mobile: экран выбора доступен, но отдельный заполненный журнал не подтверждён в этом проходе.
4. **React duplicate key предупреждение** зафиксировано при `/staff/journals` с фикстурой; консоль сообщает повторяющийся key. Снимок: `staff/staff_journals/desktop-staff_journals.png`.
5. 401/404 в консоли связаны с начальным refresh без cookie, проверкой неверного входа и намеренно несуществующим URL/ID. Большая часть `ERR_ABORTED` сетевых событий возникла при автоматических быстрых переходах между маршрутами до завершения фоновых запросов; их нельзя считать подтверждёнными серверными отказами.

Итого браузер зарегистрировал 11 console error/warning событий и 129 прерванных запросов (преимущественно `ERR_ABORTED` на навигации). Переполнения по замерам нет. Детализация исходных событий находится в `browser-observations.json`.

## Не покрыто / ограничения

- Не созданы mock состояния skeleton/loading, искусственные 500/timeout/403/401 и сетевые задержки; не снимались pending-submit и session-expiry. Реальный 500 для academics отмечен отдельно и не подменялся.
- Не выполнены полный CRUD пользователя, публикация news, обработка заявления, изменение статуса студента, редактирование расписания и сохранение оценки. Такие операции меняют тестовые данные и требовали бы отдельных сценариев подтверждения результата.
- Нет заявки из фикстуры, поэтому реальная деталь и все табы queue не покрыты. Не сняты все табы/дропдауны, notification drawer, мобильная навигация в открытом виде.
- Admin detail с ID=1 не валиден для созданной фикстуры; прямые маршруты некоторых страниц доступны только с соответствующими grants.
- Переданные staff fixtures позволяют проверить роль и меню, но часть данных пуста; teacher fixture не был раскрыт до заполненного журнала.
- Desktop full-page screenshots сохраняют длинное содержимое, но внешняя ширина viewport составляет 1440×900; mobile snapshots используют full-page, не фиксированный viewport crop.
- Визуальная оценка ограничена фактически показанными состояниями. Полнота покрытия: **частичная, средняя** — все крупные зоны и 4 роли представлены, но динамические бизнес-сценарии и негативные API состояния покрыты ограниченно.

- `student/schedule/mobile-navigation-open.png` — мобильная навигация раскрыта поверх расписания.
- `student/notifications/desktop-drawer-open.png` — drawer центра уведомлений поверх расписания.

## Список файлов

- `auth/login/desktop-login.png` — auth/login, desktop
- `auth/login/mobile-login.png` — auth/login, mobile
- `auth/about/desktop-about.png` — auth/about, desktop
- `shared/404/desktop-404.png` — shared/404, desktop
- `auth/login-invalid/desktop-login-invalid.png` — auth/login-invalid, desktop
- `student/schedule/desktop-schedule.png` — student/schedule, desktop
- `student/schedule/mobile-schedule.png` — student/schedule, mobile
- `student/schedule/laptop-schedule.png` — student/schedule, laptop
- `student/schedule/tablet-schedule.png` — student/schedule, tablet
- `student/schedule/smallmobile-schedule.png` — student/schedule, smallmobile
- `student/schedule-interaction/desktop-schedule-interaction.png` — student/schedule-interaction, desktop
- `student/academics/desktop-academics.png` — student/academics, desktop
- `student/academics/mobile-academics.png` — student/academics, mobile
- `student/academics-interaction/desktop-academics-interaction.png` — student/academics-interaction, desktop
- `student/services/desktop-services.png` — student/services, desktop
- `student/services/mobile-services.png` — student/services, mobile
- `student/service-academic_leave/desktop-service-academic_leave.png` — student/service-academic_leave, desktop
- `student/service-academic_transcript/desktop-service-academic_transcript.png` — student/service-academic_transcript, desktop
- `student/service-study_certificate/desktop-service-study_certificate.png` — student/service-study_certificate, desktop
- `student/services_certificate/desktop-services_certificate.png` — student/services_certificate, desktop
- `student/services_certificate/mobile-services_certificate.png` — student/services_certificate, mobile
- `student/news/desktop-news.png` — student/news, desktop
- `student/news/mobile-news.png` — student/news, mobile
- `student/news-detail/desktop-news-detail.png` — student/news-detail, desktop
- `student/profile/desktop-profile.png` — student/profile, desktop
- `student/profile/mobile-profile.png` — student/profile, mobile
- `student/applications_id/desktop-applications_id.png` — student/applications_id, desktop
- `student/applications_id/mobile-applications_id.png` — student/applications_id, mobile
- `student/academics_courses_id/desktop-academics_courses_id.png` — student/academics_courses_id, desktop
- `student/academics_courses_id/mobile-academics_courses_id.png` — student/academics_courses_id, mobile
- `shared/settings/desktop-settings.png` — shared/settings, desktop
- `shared/settings/mobile-settings.png` — shared/settings, mobile
- `teacher/landing/desktop-landing.png` — teacher/landing, desktop
- `teacher/teacher_journals/desktop-teacher_journals.png` — teacher/teacher_journals, desktop
- `teacher/teacher_journals/mobile-teacher_journals.png` — teacher/teacher_journals, mobile
- `teacher/teacher_schedule/desktop-teacher_schedule.png` — teacher/teacher_schedule, desktop
- `teacher/teacher_schedule/mobile-teacher_schedule.png` — teacher/teacher_schedule, mobile
- `admin/landing/desktop-landing.png` — admin/landing, desktop
- `admin/admin_users/desktop-admin_users.png` — admin/admin_users, desktop
- `admin/admin_users/mobile-admin_users.png` — admin/admin_users, mobile
- `admin/admin_users_new/desktop-admin_users_new.png` — admin/admin_users_new, desktop
- `admin/admin_users_new/mobile-admin_users_new.png` — admin/admin_users_new, mobile
- `admin/admin_users_id/desktop-admin_users_id.png` — admin/admin_users_id, desktop
- `admin/admin_users_id/mobile-admin_users_id.png` — admin/admin_users_id, mobile
- `staff/landing/desktop-landing.png` — staff/landing, desktop
- `staff/staff/desktop-staff.png` — staff/staff, desktop
- `staff/staff/mobile-staff.png` — staff/staff, mobile
- `staff/staff_applications/desktop-staff_applications.png` — staff/staff_applications, desktop
- `staff/staff_applications/mobile-staff_applications.png` — staff/staff_applications, mobile
- `staff/staff_journals/desktop-staff_journals.png` — staff/staff_journals, desktop
- `staff/staff_journals/mobile-staff_journals.png` — staff/staff_journals, mobile
- `staff/staff_schedule/desktop-staff_schedule.png` — staff/staff_schedule, desktop
- `staff/staff_schedule/mobile-staff_schedule.png` — staff/staff_schedule, mobile
- `staff/staff_news/desktop-staff_news.png` — staff/staff_news, desktop
- `staff/staff_news/mobile-staff_news.png` — staff/staff_news, mobile
- `staff/staff_students/desktop-staff_students.png` — staff/staff_students, desktop
- `staff/staff_students/mobile-staff_students.png` — staff/staff_students, mobile
- `staff/staff_students_status/desktop-staff_students_status.png` — staff/staff_students_status, desktop
- `staff/staff_students_status/mobile-staff_students_status.png` — staff/staff_students_status, mobile
- `staff-reviewer/landing/desktop-landing.png` — staff-reviewer/landing, desktop
- `staff-reviewer/staff/desktop-staff.png` — staff-reviewer/staff, desktop
- `staff-reviewer/staff_applications/desktop-staff_applications.png` — staff-reviewer/staff_applications, desktop
- `staff-reviewer/staff_journals/desktop-staff_journals.png` — staff-reviewer/staff_journals, desktop
- `staff-reviewer/staff_schedule/desktop-staff_schedule.png` — staff-reviewer/staff_schedule, desktop
- `staff-reviewer/staff_news/desktop-staff_news.png` — staff-reviewer/staff_news, desktop
- `staff-reviewer/staff_students/desktop-staff_students.png` — staff-reviewer/staff_students, desktop
- `staff-reviewer/staff_students_status/desktop-staff_students_status.png` — staff-reviewer/staff_students_status, desktop
- `staff-empty/landing/desktop-landing.png` — staff-empty/landing, desktop
- `staff-empty/staff/desktop-staff.png` — staff-empty/staff, desktop
- `staff-empty/staff_applications/desktop-staff_applications.png` — staff-empty/staff_applications, desktop
- `staff-empty/staff_journals/desktop-staff_journals.png` — staff-empty/staff_journals, desktop
- `staff-empty/staff_schedule/desktop-staff_schedule.png` — staff-empty/staff_schedule, desktop
- `staff-empty/staff_news/desktop-staff_news.png` — staff-empty/staff_news, desktop
- `staff-empty/staff_students/desktop-staff_students.png` — staff-empty/staff_students, desktop
- `staff-empty/staff_students_status/desktop-staff_students_status.png` — staff-empty/staff_students_status, desktop
